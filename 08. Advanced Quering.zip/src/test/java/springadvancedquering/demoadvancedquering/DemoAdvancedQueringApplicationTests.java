package springadvancedquering.demoadvancedquering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAdvancedQueringApplicationTests {

    @Test
    void contextLoads() {
    }

}
