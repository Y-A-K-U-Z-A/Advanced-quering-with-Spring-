package springadvancedquering.demoadvancedquering;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import springadvancedquering.demoadvancedquering.entities.Shampoo;
import springadvancedquering.demoadvancedquering.repository.IngredientRepository;
import springadvancedquering.demoadvancedquering.repository.LabelRepository;
import springadvancedquering.demoadvancedquering.repository.ShampooRepository;
import springadvancedquering.demoadvancedquering.util.PrintUtil;

import java.util.List;

import static springadvancedquering.demoadvancedquering.entities.Size.MEDIUM;

@SpringBootApplication
public class DemoAdvancedQueringApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoAdvancedQueringApplication.class, args);
    }

}
