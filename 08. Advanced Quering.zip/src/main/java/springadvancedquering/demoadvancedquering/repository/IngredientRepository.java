package springadvancedquering.demoadvancedquering.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import springadvancedquering.demoadvancedquering.entities.Ingredient;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface IngredientRepository extends JpaRepository<Ingredient, Long> {
    List<Ingredient> findAllByNameIsStartingWith(String letter);

    @Query("select i from Ingredient as i where i.name in (?1) order by i.price asc ")
    List<Ingredient> findAllByNameInOrderByPriceAsc(String[] arr);

//    counts all shampoos with price lower than a given price
    @Query("select i from Ingredient as i where i.price <= ?1")
    List<Ingredient> findAllByCountPrice(double price);

    @Transactional
    int deleteByName(String name);

    //increase price
    @Modifying
    @Query("update Ingredient as i set i.price = i.price + (i.price*0.1) where i.name in (?1)")
    void increasePriceIngredientIn(String[] arr);

    List<Ingredient> findAllByNameIn(String[] arr);

    Ingredient findByName(String name);

    @Modifying
    @Query("update Ingredient as i set i.price = i.price + (i.price*0.1) where i.name = ?1")
    void setNewPriceToIngredient(String ingredient);
}
