package springadvancedquering.demoadvancedquering.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import springadvancedquering.demoadvancedquering.entities.Ingredient;
import springadvancedquering.demoadvancedquering.entities.Shampoo;
import springadvancedquering.demoadvancedquering.entities.Size;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ShampooRepository extends JpaRepository<Shampoo, Long> {
    List<Shampoo> findBySizeOrderById(Size size);

    List<Shampoo> findBySizeOrLabelIdOrderByPrice(Size size, long labelId);

    List<Shampoo> findByPriceAfterOrderByPriceDesc(double price);

    @Query("select s from Shampoo as s join s.ingredients as i where i.name in (?1)")
    List<Shampoo> findAllByIngredientsInArray(String[] array);

    @Query("select s from Shampoo as s where s.ingredients.size < ?1")
    List<Shampoo> findByIngredientByNumber(int number);


    @Query("select s from Shampoo as s join s.ingredients as i where i.name = ?1")
    List<Shampoo> findByIngredientName(String ingredient);

    @Query("select s from Shampoo as s join s.ingredients as i where i.name in (?1)")
    List<Shampoo> findShampoosByIngredients(String[] arr);

}
