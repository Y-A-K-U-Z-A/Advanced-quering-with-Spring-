package springadvancedquering.demoadvancedquering.util;


import springadvancedquering.demoadvancedquering.entities.Ingredient;
import springadvancedquering.demoadvancedquering.entities.Shampoo;

public class PrintUtil {
    public  void printShampoo(Shampoo s) {
        System.out.format("|%5d | %-30.30s | %-8.8s | %8.2f | %-40.40s |%n",
                s.getId(), s.getBrand(), s.getSize(), s.getPrice(),
                s.getLabel().getTitle() + " - " + s.getLabel().getSubtitle());
    }

    public void printIngredient(Ingredient ingredient) {
        System.out.println(ingredient.getName() + " " + ingredient.getPrice());
    }
}