package springadvancedquering.demoadvancedquering.entities;

public enum Size {
    SMALL, MEDIUM, LARGE;
}
