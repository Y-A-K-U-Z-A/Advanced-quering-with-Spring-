package springadvancedquering.demoadvancedquering;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import springadvancedquering.demoadvancedquering.entities.Ingredient;
import springadvancedquering.demoadvancedquering.entities.Shampoo;
import springadvancedquering.demoadvancedquering.repository.IngredientRepository;
import springadvancedquering.demoadvancedquering.repository.LabelRepository;
import springadvancedquering.demoadvancedquering.repository.ShampooRepository;
import springadvancedquering.demoadvancedquering.util.PrintUtil;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static springadvancedquering.demoadvancedquering.entities.Size.MEDIUM;

@Component
public class AppInitializer implements CommandLineRunner {
    private final ShampooRepository shampooRepo;
    private final LabelRepository labelRepo;
    private final IngredientRepository ingredientRepo;
    private final PrintUtil printUtil = new PrintUtil();

    @Autowired
    public AppInitializer(ShampooRepository shampooRepo, LabelRepository labelRepo, IngredientRepository ingredientRepo) {
        this.shampooRepo = shampooRepo;
        this.labelRepo = labelRepo;
        this.ingredientRepo = ingredientRepo;
    }

    @Override
    public void run(String... args) throws Exception {
//        selectShampooBySize();
//        selectShampooBySizeOrLabel();
//        selectShampooByPriceHigherThan();
//        selectIngredientByPrefix();
//        selectIngredientByList();
//        selectIngredientByCountPrice();
//        selectShampooByIngredients();
//        selectShampooByIngredientByLessNumber();

//        deleteIngredientByName();
        updateIngredientPrice();
    }

    private void updateIngredientPrice() {
        String[] str = new String[]{"Cherry", "Berry", "Raspberry", "Wild Rose"};

        List<Shampoo> shampooWithIngredient = shampooRepo.findShampoosByIngredients(str);
        shampooWithIngredient.forEach(s ->{
            Set<Ingredient> ingredients = s.getIngredients();
            ingredients.forEach(i -> {
                i.setPrice(i.getPrice() + i.getPrice()*0.1);
                ingredientRepo.saveAndFlush(i);
            });
        });

        List<Ingredient> list = ingredientRepo.findAllByNameIn(str);
        list.forEach(i -> {
            i.setPrice(i.getPrice() + i.getPrice()*0.1);
            ingredientRepo.saveAndFlush(i);
        });
        printIngredient(list);
    }

    private void deleteIngredientByName() {
        Ingredient ingredientToDelete = ingredientRepo.findByName("Macadamia Oil");
        List<Shampoo> byIngredient = shampooRepo.findByIngredientName(ingredientToDelete.getName());

        printShampoo(byIngredient);
        byIngredient.forEach(shampoo -> shampoo.getIngredients().remove(ingredientToDelete));

        System.out.println(ingredientRepo.deleteByName("Macadamia Oil"));

        System.out.println();
        System.out.println();
        printShampoo(shampooRepo.findAll());
    }

    private void selectShampooByIngredientByLessNumber() {
        List<Shampoo> list = shampooRepo.findByIngredientByNumber(2);
        printShampoo(list);
    }

    private void selectShampooByIngredients() {
        String[] names = new String[]{"Berry", "Mineral-Collagen"};
        List<Shampoo> list = shampooRepo.findAllByIngredientsInArray(names);
        printShampoo(list);
    }

    private void selectIngredientByCountPrice() {
        List<Ingredient> list = ingredientRepo.findAllByCountPrice(8.50);
        System.out.println(list.size());
    }

    private void selectIngredientByList() {
        String[] str = new String[]{"Herbs", "Apple", "Lavender"};
        List<Ingredient> ingredients = ingredientRepo.findAllByNameInOrderByPriceAsc(str);
        printIngredient(ingredients);
    }

    private void selectIngredientByPrefix() {
        List<Ingredient> ingredients = ingredientRepo.findAllByNameIsStartingWith("M");
        printIngredient(ingredients);
    }

    private void printIngredient(List<Ingredient> ingredients) {
        for (Ingredient ingredient : ingredients) {
            printUtil.printIngredient(ingredient);
        }
    }

    private void selectShampooByPriceHigherThan() {
        List<Shampoo> list = shampooRepo.findByPriceAfterOrderByPriceDesc(10.00);
        printShampoo(list);
    }

    private void selectShampooBySizeOrLabel() {
        List<Shampoo> list = shampooRepo.findBySizeOrLabelIdOrderByPrice(MEDIUM, 10);
        printShampoo(list);
    }

    private void printShampoo(List<Shampoo> list) {
        for (Shampoo shampoo : list) {
            printUtil.printShampoo(shampoo);
        }
    }

    private void selectShampooBySize() {
        List<Shampoo> shampoos = shampooRepo.findBySizeOrderById(MEDIUM);
        printShampoo(shampoos);
    }

}
